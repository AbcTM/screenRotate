//
//  XXKKNavigationController.swift
//  ScreenRotateDemo
//
//  Created by tianlc on 2019/3/6.
//  Copyright © 2019 tianlc. All rights reserved.
//

import UIKit

class XXKKNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    
    // MARK: - 旋转
    
    // 以viewcontroller为主
    /// 设置是否让页面支持自动旋转屏幕
    override var shouldAutorotate: Bool {
        return self.topViewController?.shouldAutorotate ?? false
    }
    
    /// 支持的方向
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return self.topViewController?.supportedInterfaceOrientations ?? [UIInterfaceOrientationMask.portrait] // UIInterfaceOrientationMask.portrait, UIInterfaceOrientationMask.landscapeLeft,
    }
    
    /// 进入视图的方向
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return self.topViewController?.preferredInterfaceOrientationForPresentation ?? UIInterfaceOrientation.portrait
    }
}
