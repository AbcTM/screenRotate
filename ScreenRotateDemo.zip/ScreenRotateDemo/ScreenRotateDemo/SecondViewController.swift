//
//  SecondViewController.swift
//  ScreenRotateDemo
//
//  Created by tianlc on 2019/3/6.
//  Copyright © 2019 tianlc. All rights reserved.
//

import UIKit



class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // MARK: - 状态显示（恢复）
    
    
    // MARK: -
    
    
    // MARK: - Navigation
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        
        print("shouldPerformSegue withIdentifier:\(identifier) ")
        return super.shouldPerformSegue(withIdentifier: identifier, sender: sender)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        print("prepare segue:\(segue.description) ")
    }
    
    // MARK: - 旋转
    /// 设置是否让页面支持自动旋转屏幕
    override var shouldAutorotate: Bool {
        return true
    }
    
    /// 支持的方向
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return [UIInterfaceOrientationMask.portrait, UIInterfaceOrientationMask.landscapeLeft, UIInterfaceOrientationMask.landscapeRight]
    }
    
    /// 进入视图的方向
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return UIInterfaceOrientation.landscapeLeft
    }
}
