//
//  ViewController.swift
//  ForceScreenRotateDemo
//
//  Created by tianlc on 2019/3/6.
//  Copyright © 2019 tianlc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var bgView: UIView!
    // 第一种假旋转
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    var viewHeightConstraint: NSLayoutConstraint!
    var viewBottomConstraint: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let identifier = UIDevice.current.identifierForVendor?.description ?? "nil"
        print(identifier)
        viewBottomConstraint = bgView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        viewHeightConstraint = bgView.heightAnchor.constraint(equalToConstant: 200)
        viewHeightConstraint.isActive = true
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }

    @IBAction func rationAction(_ sender: Any) {
        var temp: UIInterfaceOrientationMask = .portrait
        
        appDelegate.supportedInterfaceOrientations = { (window) -> UIInterfaceOrientationMask in
            return temp
        }
        
        if UIDevice.current.orientation == .landscapeRight {
            let right = UIDeviceOrientation.portrait
            UIDevice.current.setValue(right.rawValue, forKey: "orientation")
        }else{
            temp = .landscapeRight
            let right = UIDeviceOrientation.landscapeRight
            UIDevice.current.setValue(right.rawValue, forKey: "orientation")
        }
    }
    
    // MARK: - 屏幕产生旋转的通知
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
//        print(coordinator.transitionDuration.debugDescription)
        
        if UIDevice.current.orientation == .landscapeRight {
            viewHeightConstraint.isActive = false
            viewBottomConstraint.isActive = true
        }else{
            viewBottomConstraint.isActive = false
            viewHeightConstraint.isActive = true
        }
        
        super.viewWillTransition(to: size, with: coordinator)
    }
}

